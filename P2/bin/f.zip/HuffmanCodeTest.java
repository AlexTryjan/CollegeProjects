import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;


public class HuffmanCodeTest {
	
	/* Other JUnit tests.
     * 
     * Write your own JUnit tests below to check the correctness of your implementation.
     * 
     * When you turn in your draft (and final) we will run our own test suite on your code 
     * and provide you with the feedback.
     * 
     * Your draft code should contain a complete set of methods as specified in the assignment.
     * Any methods not yet implemented should be written as skeleton methods with an empty body. 
     * 
	 * The JUnit tests below help to ensure that your methods compile with our test suite and have 
	 * correctly typed arguments. You can replace them with more meaningful tests to test their
	 * functionalities.
     */
	
	@Test
	public void testByteArrayArgumentConstructor() {
    	HuffmanCode hc = new HuffmanCode(new byte [] {(byte)'a', (byte)'b'});
    	assertTrue("The constructor make a HuffmanCode using byte array",
			true);
	}
	
	@Test
	public void testStringArgumentConstructor() throws IOException {
    	HuffmanCode hc = new HuffmanCode("/Users/aetryjan/file.txt");
    	assertTrue("The constructor make a HuffmanCode from a file",
			true);
	}
	
	@Test
	public void testByteAndCountArraysConstructorAndToString() {
    	HuffmanCode hc = new HuffmanCode(new byte [] {(byte)'a', (byte)'b', (byte)'c', (byte)' ', (byte)'?'}, new int [] {3, 2, 1, 1, 1});
    	assertEquals("The constructor makes a HuffmanCode using byte and count arrays",
    				"10",hc.codeString((byte)'b'));
    	assertEquals("110",hc.codeString((byte)'c'));
    	assertEquals("1110",hc.codeString((byte)' '));
    	assertEquals("1111",hc.codeString((byte)'?'));
    	assertEquals("0",hc.codeString((byte)'a'));
	}
	
	@Test
	public void testCodeMethod()throws IOException {
    	HuffmanCode hc = new HuffmanCode(new byte [] {(byte)'a', (byte)'b', (byte)'c'}, new int [] {3, 2, 1});
    	boolean[] code = hc.code((byte)'a');
    	boolean[] binary = new boolean[] {true};
    	assertEquals(binary[0],code[0]);
	}
	
	@Test
	public void testToStringMethod() {
    	HuffmanCode hc = new HuffmanCode(new byte [] {(byte)'a', (byte)'b', (byte)'c', (byte)' ', (byte)'?'}, new int [] {3, 2, 1, 1, 1});
    	String s = hc.toString();
    	assertEquals("This method returns astring containing the table of the binary encodings of each byte in the Huffman tree",
			"97: 0"+"\n"+"98: 10"+"\n"+"32: 1110"+"\n"+"63: 1111"+"\n"+"99: 110",s);
	}
}